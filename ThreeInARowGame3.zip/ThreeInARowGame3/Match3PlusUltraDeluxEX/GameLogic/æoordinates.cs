﻿using System;

namespace ThreeInARowGame3.GameLogic
{
    public struct Сoordinates : IEquatable<Сoordinates>
    {
        public static readonly Сoordinates NullObject = new Сoordinates(-1, -1);

        public int X { get; }
        public int Y { get; }

        public Сoordinates(int x, int y)
        {
            X = x;
            Y = y;
        }

        public bool IsNearby(Сoordinates other)
        {
            return other.X == X && Math.Abs(other.Y - Y) == 1
                || other.Y == Y && Math.Abs(other.X - X) == 1;
        }

        public override string ToString()
        {
            return $"[{X}; {Y}]";
        }

        public override bool Equals(object obj)
        {
            return obj is Сoordinates vector && Equals(vector);
        }

        public bool Equals(Сoordinates other)
        {
            return X == other.X && Y == other.Y;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(X, Y);
        }

        public static bool operator ==(Сoordinates left, Сoordinates right)
        {
            return left.Equals(right);
        }

        public static bool operator !=(Сoordinates left, Сoordinates right)
        {
            return !left.Equals(right);
        }
    }
}