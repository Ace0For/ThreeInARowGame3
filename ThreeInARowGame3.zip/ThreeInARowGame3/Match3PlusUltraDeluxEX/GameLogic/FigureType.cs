﻿namespace ThreeInARowGame3.GameLogic
{
    public enum FigureType
    {
        Red,
        Green,
        Blue,
        Yellow,
        Pink
    }
}