﻿using System;
using System.Collections.Generic;

namespace ThreeInARowGame3.GameLogic
{
    public class GameGridLogic
    {
        private readonly Random _random = new Random();
        private readonly IFigure[,] _figures;
        private readonly int _gridSize;

        public GameGridLogic(int gridSize)
        {
            _gridSize = gridSize;
            _figures = new IFigure[_gridSize, _gridSize];
            FillRandomFigures();
        }

        public IFigure GetFigure(Сoordinates position) => _figures[position.X, position.Y];

        private void SwapFigures(int x1, int y1, int x2, int y2)
        {
            (_figures[x1, y1].Position, _figures[x2, y2].Position) = (_figures[x2, y2].Position, _figures[x1, y1].Position);
            (_figures[x1, y1], _figures[x2, y2]) = (_figures[x2, y2], _figures[x1, y1]);
        }

        public void SwapFigures(Сoordinates firstPosition, Сoordinates secondPosition) => SwapFigures(firstPosition.X, firstPosition.Y, secondPosition.X, secondPosition.Y);

        public bool TryMatchAll()
        {
            bool isMatched = false;
            for (int i = 0; i < _gridSize; i++)
            {
                for (int j = 0; j < _gridSize; j++)
                {
                    if (ExecuteMatch(new Сoordinates(i, j), ref _figures[i, j]))
                    {
                        isMatched = true;
                    }
                }
            }
            return isMatched;
        }

        public bool TryMatch(Сoordinates firstPosition, Сoordinates secondPosition)
        {
            var firstTry = ExecuteMatch(secondPosition, ref _figures[secondPosition.X, secondPosition.Y]);
            var secondTry = ExecuteMatch(firstPosition, ref _figures[firstPosition.X, firstPosition.Y]);
            return firstTry || secondTry;
        }

        public void PushFiguresDown(out List<Сoordinates> dropsFrom, out List<Сoordinates> dropsTo)
        {
            dropsFrom = new List<Сoordinates>();
            dropsTo = new List<Сoordinates>();
            for (int i = 0; i < _gridSize; i++)
            {
                int gap = 0;
                for (int j = _gridSize - 1; j >= 0; j--)
                {
                    if (_figures[i, j].IsNullObject)
                    {
                        gap++;
                    }
                    else
                    {
                        SwapFigures(i, j + gap, i, j);
                        dropsFrom.Add(new Сoordinates(i, j));
                        dropsTo.Add(new Сoordinates(i, j + gap));
                    }
                }
            }
        }

        public void FillRandomFigures()
        {
            var figureTypes = Enum.GetValues(typeof(FigureType));
            for (int i = 0; i < _gridSize; i++)
            {
                for (int j = 0; j < _gridSize; j++)
                {
                    if (_figures[i, j] == null || _figures[i, j].IsNullObject)
                    {
                        var randomType = (FigureType)figureTypes.GetValue(_random.Next(figureTypes.Length));
                        _figures[i, j] = new BasicFigure(randomType, new Сoordinates(i, j));
                    }
                }
            }
        }

        private bool ExecuteMatch(Сoordinates position, ref IFigure firstFigure)
        {
            var matchList = GetMatchList(position, firstFigure.Type);

            if (matchList.Count == 0)
            {
                return false;
            }

            foreach (var figure in matchList)
            {
                figure.Destroy(_figures);
            }
            return true;
        }

        private List<IFigure> GetMatchList(Сoordinates position, FigureType type)
        {
            int horCounter = position.X + 1;
            int vertCounter = position.Y + 1;
            var verticalLine = new List<IFigure>();
            var horizontalLine = new List<IFigure>();
            while (horCounter < _gridSize)
            {
                if (_figures[horCounter, position.Y].Type != type)
                {
                    break;
                }

                horizontalLine.Add(_figures[horCounter, position.Y]);
                horCounter++;
            }
            while (vertCounter < _gridSize)
            {
                if (_figures[position.X, vertCounter].Type != type)
                {
                    break;
                }

                verticalLine.Add(_figures[position.X, vertCounter]);
                vertCounter++;
            }

            horCounter = position.X - 1;
            vertCounter = position.Y - 1;
            while (horCounter >= 0)
            {
                if (_figures[horCounter, position.Y].Type != type)
                {
                    break;
                }

                horizontalLine.Add(_figures[horCounter, position.Y]);
                horCounter--;
            }
            while (vertCounter >= 0)
            {
                if (_figures[position.X, vertCounter].Type != type)
                {
                    break;
                }

                verticalLine.Add(_figures[position.X, vertCounter]);
                vertCounter--;
            }

            if (verticalLine.Count < 2)
            {
                verticalLine.Clear();
            }
            if (horizontalLine.Count < 2)
            {
                horizontalLine.Clear();
            }

            verticalLine.AddRange(horizontalLine);
            return verticalLine;
        }
    }
}