﻿using System.Windows.Media.Imaging;

namespace ThreeInARowGame3.GameLogic
{
    public interface IFigure
    {
        FigureType Type { get; set; }
        Сoordinates Position { get; set; }
        bool IsNullObject { get; }
        void Destroy(IFigure[,] list);
        BitmapImage GetBitmapImage();
    }
}