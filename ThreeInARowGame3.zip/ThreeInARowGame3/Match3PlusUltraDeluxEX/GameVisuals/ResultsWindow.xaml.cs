﻿using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Text.Json;
using System.Windows;

namespace ThreeInARowGame3
{

    public partial class ResultsWindow : Window
    {
        public ObservableCollection<LeaderboardItem> LeaderboardItems;

        public ResultsWindow(int finalScore)
        {
            InitializeComponent();
            FinalScore.Text = "Score: " + finalScore;
            LeaderboardItems = new ObservableCollection<LeaderboardItem>();
            Leaderboard.ItemsSource = LeaderboardItems;
            LeaderboardItems = LoadLeaderboard();
        }
        private void SaveLeaderboard()
        {
            string json = JsonSerializer.Serialize(LeaderboardItems);
            File.WriteAllText("leaderboard.json", json);
        }

        private void BackInMenu(object sender, RoutedEventArgs e)
        {
            MenuWindow menu = new MenuWindow
            {
                Top = Top,
                Left = Left
            };
            menu.Show();
            Close();
        }
        public class LeaderboardItem
        {
            public string PlayerName { get; set; }
            public int Score { get; set; }
        }
        private void SaveNameButton_Click(object sender, RoutedEventArgs e)
        {
            InputNameDialog inputNameDialog = new InputNameDialog
            {
                Top = Top,
                Left = Left
            };

            if (inputNameDialog.ShowDialog(this) == true)
            {
                string playerName = inputNameDialog.PlayerName;

                // Получаем счет из статического поля класса Game
                int playerScore = GameLogic.GameLogic._score;

                LeaderboardItem newLeaderboardItem = new LeaderboardItem
                {
                    PlayerName = playerName,
                    Score = playerScore
                };

                LeaderboardItems.Add(newLeaderboardItem);
                SaveLeaderboard();
            }
        }

        public void ShowResults(int playerScore)
        {
            // Создаем новое окно для ввода имени
            InputNameDialog inputNameDialog = new InputNameDialog();

            // Показываем окно и проверяем результат
            if (inputNameDialog.ShowDialog() == true)
            {
                // Получаем введенное имя
                string playerName = inputNameDialog.PlayerName;

                // Создание нового элемента таблицы лидеров
                LeaderboardItem newLeaderboardItem = new LeaderboardItem
                {
                    PlayerName = playerName,
                    Score = playerScore
                };

                // Добавление элемента в таблицу лидеров
                LeaderboardItems.Add(newLeaderboardItem);

                // Сохранение таблицы лидеров в JSON
                SaveLeaderboard();
            }
        }
        private ObservableCollection<LeaderboardItem> LoadLeaderboard()
        {
            try
            {
                if (File.Exists("leaderboard.json"))
                {
                    string json = File.ReadAllText("leaderboard.json");

                    // Очищаем текущую коллекцию и добавляем элементы из загруженной коллекции
                    LeaderboardItems.Clear();
                    ObservableCollection<LeaderboardItem> loadedLeaderboard = JsonSerializer.Deserialize<ObservableCollection<LeaderboardItem>>(json);
                    foreach (LeaderboardItem item in loadedLeaderboard)
                    {
                        LeaderboardItems.Add(item);
                    }

                    return LeaderboardItems;
                }
            }
            catch (Exception ex)
            {
                // Обработайте ошибку чтения файла, если необходимо
                Console.WriteLine($"Error loading leaderboard: {ex.Message}");
            }

            // Если произошла ошибка или файл не существует, вернем новую пустую коллекцию
            return new ObservableCollection<LeaderboardItem>();
        }
    }
}