﻿using System.Windows;

namespace ThreeInARowGame3
{
    public partial class InputNameDialog : Window
    {
        public string PlayerName { get; private set; }

        public InputNameDialog()
        {
            InitializeComponent();
        }

        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            // При нажатии на кнопку OK, сохраняем введенное имя и закрываем окно
            PlayerName = nameTextBox.Text;
            DialogResult = true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            // При нажатии на кнопку Отмена, закрываем окно без сохранения имени
            DialogResult = false;
        }

        // Добавьте этот метод для отображения диалогового окна
        public bool? ShowDialog(Window owner)
        {
            Owner = owner;
            return ShowDialog();
        }
    }
}
