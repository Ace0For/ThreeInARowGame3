﻿using ThreeInARowGame3;
using ThreeInARowGame3.GameLogic;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Animation;

namespace Match3v3.GameVisuals
{
    public class GameAnimator
    {
        private const double DestroyAnimationIncrease = 25;
        private const int DestroyAnimationDurationMs = 200;
        private const int MoveAnimationDurationMs = 100;

        public void DestroyAnimation(Image figureImage)
        {
            DoubleAnimation widthAnimation = CreateDoubleAnimation(figureImage.ActualWidth, figureImage.ActualWidth + DestroyAnimationIncrease, DestroyAnimationDurationMs);
            DoubleAnimation heightAnimation = CreateDoubleAnimation(figureImage.ActualHeight, figureImage.ActualHeight + DestroyAnimationIncrease, DestroyAnimationDurationMs);
            DoubleAnimation opacityAnimation = CreateDoubleAnimation(1, 0, DestroyAnimationDurationMs);

            figureImage.BeginAnimation(UIElement.OpacityProperty, opacityAnimation);
            figureImage.BeginAnimation(FrameworkElement.WidthProperty, widthAnimation);
            figureImage.BeginAnimation(FrameworkElement.HeightProperty, heightAnimation);
        }

        public void MoveAnimation(Image figureImage, Сoordinates from, Сoordinates to)
        {
            DoubleAnimation moveAnimation;

            if (from.X == to.X)
            {
                moveAnimation = CreateDoubleAnimation(GameWindow.CanvasTop + GameWindow.CellSizePx * from.Y, GameWindow.CanvasTop + GameWindow.CellSizePx * to.Y, MoveAnimationDurationMs);
                figureImage.BeginAnimation(Canvas.TopProperty, moveAnimation);
            }
            else
            {
                moveAnimation = CreateDoubleAnimation(GameWindow.CanvasLeft + GameWindow.CellSizePx * from.X, GameWindow.CanvasLeft + GameWindow.CellSizePx * to.X, MoveAnimationDurationMs);
                figureImage.BeginAnimation(Canvas.LeftProperty, moveAnimation);
            }
        }

        private DoubleAnimation CreateDoubleAnimation(double from, double to, int durationMs)
        {
            return new DoubleAnimation
            {
                From = from,
                To = to,
                Duration = TimeSpan.FromMilliseconds(durationMs)
            };
        }
    }
}