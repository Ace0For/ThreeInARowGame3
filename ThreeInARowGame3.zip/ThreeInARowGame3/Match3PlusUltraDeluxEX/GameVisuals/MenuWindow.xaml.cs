﻿using System.Windows;
using System.Windows.Controls;

namespace ThreeInARowGame3
{
    public partial class MenuWindow : Window
    {
        public int SelectedTime { get; set; } = 60;

        public MenuWindow()
        {
            InitializeComponent();
            TimeComboBox.SelectionChanged += TimeComboBox_SelectionChanged;
        }

        private void GoPlay(object sender, RoutedEventArgs routedEventArgs)
        {
            // Указываем время игры при создании окна игры
            var game = new GameWindow(SelectedTime)
            {
                Top = Top,
                Left = Left
            };
            game.Show();
            Close();
        }

        private void GoToShop(object sender, RoutedEventArgs e)
        {
            var shopWindow = new ShopWindow
            {
                Top = Top,
                Left = Left
            };
            shopWindow.Show();
            Close();
        }
        private void TimeComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selectedItem = (ComboBoxItem)TimeComboBox.SelectedItem;
            if (selectedItem != null)
            {
                SelectedTime = int.Parse(selectedItem.Tag.ToString());
            }
        }
        private void ToggleMusic(object sender, RoutedEventArgs e)
        {
            if (BackgroundMusic.Source != null)
            {
                if (BackgroundMusic.IsMuted)
                {
                    // Если музыка выключена, включаем её
                    BackgroundMusic.IsMuted = false;
                }
                else
                {
                    // Если музыка включена, выключаем её
                    BackgroundMusic.IsMuted = true;
                }
            }
        }
    }
}