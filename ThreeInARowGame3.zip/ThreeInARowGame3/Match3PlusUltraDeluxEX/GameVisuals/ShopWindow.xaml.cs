﻿using System.Windows;

namespace ThreeInARowGame3
{
    public partial class ShopWindow : Window
    {
        public ShopWindow()
        {
            InitializeComponent();
        }

        private void BackToMainMenu(object sender, RoutedEventArgs e)
        {
            var menuWindow = new MenuWindow
            {
                Top = Top,
                Left = Left
            };
            menuWindow.Show();
            Close();
        }
    }
}
