﻿using Match3v3.GameVisuals;
using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;
using ThreeInARowGame3.GameLogic;

namespace ThreeInARowGame3
{
    public partial class GameWindow : Window
    {
        public const int GridSize = 8;
        public const int CellSizePx = 70;
        public const int CanvasTop = 80; // XAML 
        public const int CanvasLeft = 260;
        private int _timeForGame = 60;

        private readonly Dictionary<Сoordinates, Image> _images;
        private readonly Dictionary<Сoordinates, Button> _buttons;
        private readonly GameLogic.GameLogic _game;
        private readonly GameAnimator _animator;
        private DispatcherTimer _timer;
        private bool _isWindowInitialized = false;
        private int _timeSeconds;

        public GameWindow(int timeForGame)
        {
            InitializeComponent();
            _timeForGame = timeForGame;
            _game = new GameLogic.GameLogic(this, GridSize);
            _animator = new GameAnimator();
            _buttons = new Dictionary<Сoordinates, Button>();
            _images = new Dictionary<Сoordinates, Image>();
            CreateGridLayout();
            _game.Initialize();
            SetVisuals();
            InitializeCounters();

        }
        public void SetGameTime(int time)
        {
            _timeForGame = time;
        }
        private void ReturnToMenu(object sender, RoutedEventArgs e)
        {
            MenuWindow menu = new MenuWindow
            {
                Top = Top,
                Left = Left
            };
            menu.Show();
            Close();
        }
        public void MarkSelected(Сoordinates buttonIndex)
        {
            _buttons[buttonIndex].Background = new SolidColorBrush(Colors.LightCoral);
        }

        public void MarkDeselected(Сoordinates buttonIndex)
        {
            Color color = ((buttonIndex.X + buttonIndex.Y) % 2 == 0) ? Colors.LightGray : Colors.LightGoldenrodYellow;
            _buttons[buttonIndex].Background = new SolidColorBrush(color);
        }

        public void DestroyAnimation()
        {
            for (int i = 0; i < GridSize; i++)
            {
                for (int j = 0; j < GridSize; j++)
                {
                    Сoordinates position = new Сoordinates(i, j);
                    if (_game.GetFigure(position).IsNullObject)
                    {
                        _animator.DestroyAnimation(_images[position]);
                    }
                }
            }
        }

        public void SwapAnimation(Сoordinates firstPosition, Сoordinates secondPosition)
        {
            Image firstFigure = _images[firstPosition];
            Image secondFigure = _images[secondPosition];
            _animator.MoveAnimation(firstFigure, firstPosition, secondPosition);
            _animator.MoveAnimation(secondFigure, secondPosition, firstPosition);
        }

        public void PushDownAnimation(List<Сoordinates> dropsFrom, List<Сoordinates> dropsTo)
        {
            for (int i = 0; i < dropsFrom.Count; i++)
            {
                Image figure = _images[dropsFrom[i]];
                _animator.MoveAnimation(figure, dropsFrom[i], dropsTo[i]);
            }
        }

        public void SetVisuals()
        {
            for (int i = 0; i < GridSize; i++)
            {
                for (int j = 0; j < GridSize; j++)
                {
                    Сoordinates position = new Сoordinates(i, j);
                    if (GameLogic.GameLogic.IsInitialized && _isWindowInitialized)
                    {
                        CanvasLayout.Children.Remove(_images[position]);
                    }

                    IFigure figure = _game.GetFigure(position);
                    if (figure.IsNullObject)
                    {
                        continue;
                    }

                    Image image = new Image
                    {
                        Source = _game.GetFigure(position).GetBitmapImage(),
                        Width = CellSizePx
                    };
                    Canvas.SetTop(image, CanvasTop + (CellSizePx * j));
                    Canvas.SetLeft(image, CanvasLeft + (CellSizePx * i));
                    image.IsHitTestVisible = false;
                    _ = CanvasLayout.Children.Add(image);
                    _images[position] = image;
                }
            }
            UpdateScore();
            _isWindowInitialized = true;
        }

        private void UpdateScore()
        {
            int score = _game.GetScore();
            ScoreText.Text = score.ToString();
        }

        private void InitializeCounters()
        {
            GameLogic.GameLogic.NullifyScore();
            UpdateScore();
            _timeSeconds = 0;
            _timer = new DispatcherTimer();
            _timer.Tick += UpdateTime;
            _timer.Interval = new TimeSpan(0, 0, 1);
            _timer.Start();
        }

        private void UpdateTime(object sender, EventArgs e)
        {
            _timeSeconds++;
            if (_timeSeconds >= _timeForGame)
            {
                _timer.Tick -= UpdateTime;
                ResultsWindow results = new ResultsWindow(_game.GetScore())
                {
                    Top = Top,
                    Left = Left
                };
                results.Show();
                Close();
            }

            // Используйте TimeSpan для форматирования времени
            TimeSpan timeSpan = TimeSpan.FromSeconds(_timeForGame - _timeSeconds);
            TimeText.Text = $"{timeSpan.Minutes}:{timeSpan.Seconds}";
        }

        private string FormatTime(int seconds)
        {
            TimeSpan time = TimeSpan.FromSeconds(seconds);
            return $"{time.Minutes:D2}:{time.Seconds:D2}";
        }

        private void GridClick(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;
            Сoordinates id = (Сoordinates)button.DataContext;
            _game.SelectFigure(id);
        }

        private void CreateGridLayout()
        {
            for (int i = 0; i < GridSize; i++)
            {
                ColumnDefinition column = new ColumnDefinition
                {
                    Width = new GridLength(CellSizePx)
                };
                RowDefinition row = new RowDefinition()
                {
                    Height = new GridLength(CellSizePx)
                };
                GridLayout.ColumnDefinitions.Add(column);
                GridLayout.RowDefinitions.Add(row);
            }

            for (int i = 0; i < GridSize; i++)
            {
                for (int j = 0; j < GridSize; j++)
                {
                    Button button = new Button()
                    {
                        BorderThickness = new Thickness(0),
                        DataContext = new Сoordinates(i, j)
                    };
                    button.Click += GridClick;
                    Grid.SetColumn(button, i);
                    Grid.SetRow(button, j);
                    _ = GridLayout.Children.Add(button);

                    _buttons[new Сoordinates(i, j)] = button;
                }
            }
        }
        private void ToggleMusic(object sender, RoutedEventArgs e)
        {
            if (BackgroundMusic.Source != null)
            {
                if (BackgroundMusic.IsMuted)
                {
                    // Если музыка выключена, включаем её
                    BackgroundMusic.IsMuted = false;
                }
                else
                {
                    // Если музыка включена, выключаем её
                    BackgroundMusic.IsMuted = true;
                }
            }
        }
    }
}

